# Arduino-Library

  Hello friends, hope you all are fine. In today’s post, I am going to share Arduino Library for Proteus. I am quite excited about today’s post as its my first complete Arduino Library for Proteus. In my previous posts, I have shared these boards in separate libraries but today I am gonna combine all the boards together in single library so that you just simple install this library in your Proteus software and you get all the boards in your Proteus workspace. You must also give a try to Genuino Library for Proteus.

  I have already posted few other Arduino Libraries on my blog but those were third party Libraries and has nothing to do with us. We were sharing them just for the sake of knowledge but today I am going to share our very own Arduino library for Proteus, designed by our team after a lot of hard work. We have tested all the boards with different types of hardware and there’s not a single bug present in it. So, now you can easily use Arduino boards in Proteus and can simulate any kind of project in Proteus. If you got any trouble then you can ask in comments or can use our Ask Question forum to post your questions.

  This Arduino Library for Proteus is unique in its kind because there’s no such library posted before which has as much boards as we have in our Library. We have added almost all the basics Arduino boards in it and we are also working on advance boards like Arduino DUE and other Arduino shields like Arduino Wifi and Ethernet etc. Once we completed those libraries and tested as well, then I will update them in this post as well. You should also have a look at Arduino Tutorial for Beginners. Rite now this Arduino Library for Proteus contains following boards in it in it:

- Arduino UNO
- Arduino Mega 2560
- Arduino Mega 1280
- Arduino Nano
- Arduino Mini
- Arduino Pro Mini

So, I hope you are gonna like and enjoy today’s post quite a lot. So, let’s get started with Arduino Library for Proteus.
